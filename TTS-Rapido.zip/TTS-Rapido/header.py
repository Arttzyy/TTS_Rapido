badges = """
<div style="display: flex">
<span style="margin-right: 5px"> 

[ ![GitHub](https://img.shields.io/badge/github-%23121011.svg?style=for-the-badge&logo=github&logoColor=white) ](https://github.com/rafaelGodoyEbert)
 
</span>
<span style="margin-right: 5px"> 

[ ![Twitter](https://img.shields.io/badge/Twitter-%231DA1F2.svg?style=for-the-badge&logo=Twitter&logoColor=white) ](https://twitter.com/GodoyEbert)
 
</span>
<span>

[ ![](https://dcbadge.vercel.app/api/server/aihubbrasil) ](https://discord.gg/aihubbrasil)

</span>
</div>
"""

description = """
# QuickTTS
 QuickTTS, para todos aqueles que sempre me pediam alguma forma de fazer algum TTS.<br>
 Tem em diversos idiomas, só aproveitar<br>
 Increva-se no canal do <a href='https://www.youtube.com/@aihubbrasil' target='_blank'>Youtube do AI HUB Brasil</a> e no meu pessoal <a href='https://www.youtube.com/@godoyy' target='_blank'>Godoyy</a>
"""